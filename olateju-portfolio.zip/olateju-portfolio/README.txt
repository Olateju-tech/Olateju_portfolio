OLATEJU AISHAT SOTUNBO — PORTFOLIO

This folder is a ready-to-publish static website.

FASTEST WAY TO PUT IT ONLINE
1. Create/sign in to a Netlify account.
2. Open Netlify Drop.
3. Drag this entire folder into the drop area.
4. Netlify will give you a live .netlify.app URL.
5. You can then copy that URL into Google Docs, your CV, applications, etc.

The site contains:
• Your portrait
• ASMA ad copy links
• ASMA video script links
• The Story Lens
• Velo Pulse article
• Your Substack
• ASMA published pieces
• Contact section

To update the portfolio later, replace/edit index.html and redeploy the folder.
